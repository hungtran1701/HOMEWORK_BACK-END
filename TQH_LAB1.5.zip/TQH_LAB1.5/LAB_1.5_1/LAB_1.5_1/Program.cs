﻿using System;
using System.Collections.Generic;
using System.Text;
using LAB_1._5_1;

namespace LAB_1._5_1
{
    class Program
    {
        // Danh sách phân số
        public static List<Phanso> danhsachs = new List<Phanso>()
        {
            new Phanso(1, 2), // 1/2
            new Phanso(1, 3), // 1/3
            new Phanso(1, 6), // 1/6
            new Phanso(2, 5), // 2/5
            new Phanso(3, 4)  // 3/4
        };

        // Thêm phân số
        public static bool AddPhanso(Phanso ps)
        {
            try
            {
                danhsachs.Add(ps);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        // Sửa phân số
        public static bool EditPhanso(int index, Phanso ps)
        {
            try
            {
                if (index >= 0 && index < danhsachs.Count)
                {
                    danhsachs[index] = ps;
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        // Xóa phân số
        public static bool DeletePhanso(int index)
        {
            try
            {
                if (index >= 0 && index < danhsachs.Count)
                {
                    danhsachs.RemoveAt(index);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        // Hiển thị danh sách và tổng
        public static void GetPhansos()
        {
            Console.WriteLine("STT\tPHÂN SỐ");
            for (int i = 0; i < danhsachs.Count; i++)
            {
                Console.WriteLine($"{i}\t{danhsachs[i]}");
            }

            // Tính tổng
            if (danhsachs.Count > 0)
            {
                Phanso tong = danhsachs[0];
                for (int i = 1; i < danhsachs.Count; i++)
                {
                    tong = tong.Cong(danhsachs[i]);
                }
                Console.WriteLine($"\nTổng các phân số: {tong}");
            }
            else
            {
                Console.WriteLine("\nDanh sách rỗng!");
            }
        }

        // Thông báo
        public static void Alert(bool isSuccess, string action)
        {
            string message = isSuccess ? $"{action} thành công!" : $"{action} thất bại!";
            Console.WriteLine(message);
            Console.WriteLine("Nhấn phím bất kỳ để tiếp tục...");
            Console.ReadLine();
        }

        // Hiển thị menu
        public static void GetMenu()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("-----------------------Quản lý phân số-----------------------");
                GetPhansos();
                Console.WriteLine("-------------------------------------------------------------");
                Console.WriteLine("\t1. Thêm phân số");
                Console.WriteLine("\t2. Sửa phân số");
                Console.WriteLine("\t3. Xóa phân số");
                Console.WriteLine("\t4. Thoát");
                do
                {
                    try
                    {
                        Console.Write("- Mời bạn chọn chức năng: ");
                        choice = int.Parse(Console.ReadLine() ?? "0");
                        if (choice < 1 || choice > 4)
                            Console.WriteLine("Vui lòng chọn từ 1 đến 4!");
                        else
                            break;
                    }
                    catch
                    {
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                    }
                } while (true);

                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("- Nhập phân số mới:");
                            Phanso ps = new Phanso();
                            ps.NhapPhanSo();
                            Alert(AddPhanso(ps), "Thêm");
                        }
                        break;

                    case 2:
                        {
                            Console.Write("- Nhập số thứ tự (STT) phân số muốn sửa: ");
                            try
                            {
                                int index = int.Parse(Console.ReadLine() ?? "0");
                                if (index >= 0 && index < danhsachs.Count)
                                {
                                    Console.WriteLine("- Nhập thông tin mới:");
                                    Phanso ps = new Phanso();
                                    ps.NhapPhanSo();
                                    Alert(EditPhanso(index, ps), "Sửa");
                                }
                                else
                                {
                                    Alert(false, "Sửa");
                                }
                            }
                            catch
                            {
                                Alert(false, "Sửa");
                            }
                        }
                        break;

                    case 3:
                        {
                            Console.Write("- Nhập số thứ tự (STT) phân số muốn xóa: ");
                            try
                            {
                                int index = int.Parse(Console.ReadLine() ?? "0");
                                Alert(DeletePhanso(index), "Xóa");
                            }
                            catch
                            {
                                Alert(false, "Xóa");
                            }
                        }
                        break;

                    default:
                        break;
                }
            } while (choice != 4);
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            GetMenu();
        }
    }
}