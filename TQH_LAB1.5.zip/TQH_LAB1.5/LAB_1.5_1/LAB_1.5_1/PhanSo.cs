﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_1._5_1
{
    public class Phanso
    {
        private int tuSo;
        private int mauSo;

        // Expression-bodied properties
        public int TuSo
        {
            get => tuSo;
            set => tuSo = value;
        }

        public int MauSo
        {
            get => mauSo;
            set => mauSo = value == 0 ? throw new ArgumentException("Mẫu số không thể bằng 0!") : value;
        }

        // Constructor mặc định
        public Phanso()
        {
            tuSo = 0;
            mauSo = 1;
        }

        // Constructor với tham số
        public Phanso(int tu, int mau)
        {
            tuSo = tu;
            MauSo = mau; // Sử dụng property để kiểm tra mẫu số
            RutGon();
        }

        // Tìm ước chung lớn nhất (UCLN)
        private int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        // Rút gọn phân số
        private void RutGon()
        {
            int ucln = UCLN(tuSo, mauSo);
            tuSo /= ucln;
            mauSo /= ucln;
            if (mauSo < 0)
            {
                tuSo = -tuSo;
                mauSo = -mauSo;
            }
        }

        // Nhập phân số với xử lý lỗi
        public void NhapPhanSo()
        {
            bool validInput;
            do
            {
                Console.Write("Nhập tử số: ");
                string input = Console.ReadLine();
                validInput = int.TryParse(input, out tuSo);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Tử số không được để trống!");
                    else
                        Console.WriteLine("Tử số phải là số nguyên!");
                }
            } while (!validInput);

            do
            {
                Console.Write("Nhập mẫu số (khác 0): ");
                string input = Console.ReadLine();
                validInput = int.TryParse(input, out int tempMauSo);
                if (!validInput)
                {
                    if (string.IsNullOrEmpty(input))
                        Console.WriteLine("Mẫu số không được để trống!");
                    else
                        Console.WriteLine("Mẫu số phải là số nguyên!");
                }
                else
                {
                    try
                    {
                        MauSo = tempMauSo;
                        validInput = true;
                    }
                    catch (ArgumentException ex)
                    {
                        Console.WriteLine(ex.Message);
                        validInput = false;
                    }
                }
            } while (!validInput);

            RutGon();
        }

        // Hiển thị phân số
        public override string ToString()
        {
            if (tuSo == 0) return "0";
            if (mauSo == 1) return tuSo.ToString();
            return $"{tuSo}/{mauSo}";
        }

        // Cộng hai phân số
        public Phanso Cong(Phanso ps)
        {
            int tuMoi = tuSo * ps.mauSo + ps.tuSo * mauSo;
            int mauMoi = mauSo * ps.mauSo;
            return new Phanso(tuMoi, mauMoi);
        }
    }
}
