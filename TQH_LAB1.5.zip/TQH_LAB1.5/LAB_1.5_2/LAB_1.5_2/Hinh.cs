﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_1._5_2
{
        abstract class Hinh
        {
            public abstract double TinhChuVi();
            public abstract double TinhDienTich();
            public abstract void Nhap();
        }
}
