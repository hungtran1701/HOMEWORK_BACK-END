﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_1._5_2
{
    class HinhTron : Hinh
    {
        private double banKinh;

        public override void Nhap()
        {
            Console.Write("Nhập bán kính: ");
            banKinh = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi() => 2 * Math.PI * banKinh;
        public override double TinhDienTich() => Math.PI * banKinh * banKinh;
    }
}
