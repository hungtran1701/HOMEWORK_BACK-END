﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_1._5_2
{
    class HinhTamGiac : Hinh
    {
        private double a, b, c;

        public override void Nhap()
        {
            Console.Write("Nhập cạnh a: ");
            a = double.Parse(Console.ReadLine());
            Console.Write("Nhập cạnh b: ");
            b = double.Parse(Console.ReadLine());
            Console.Write("Nhập cạnh c: ");
            c = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi() => a + b + c;

        public override double TinhDienTich()
        {
            double p = TinhChuVi() / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
        }
    }
}
