﻿using System;
using System.Collections.Generic;
using System.Text;
using LAB_1._5_2;

Console.OutputEncoding = System.Text.Encoding.UTF8;
List<Hinh> danhSachHinh = new List<Hinh>();

// Nhập số lượng hình
Console.Write("Nhập số lượng hình: ");
int n = int.Parse(Console.ReadLine());

// Nhập thông tin các hình
for (int i = 0; i < n; i++)
{
    Console.WriteLine($"\nHình {i + 1}:");
    Console.Write("Chọn loại (1-Tròn, 2-Vuông, 3-Tam giác, 4-Chữ nhật): ");
    int loai = int.Parse(Console.ReadLine());

    Hinh hinh = loai switch
    {
        1 => new HinhTron(),
        2 => new HinhVuong(),
        3 => new HinhTamGiac(),
        4 => new HinhChuNhat(),
        _ => null
    };

    if (hinh == null)
    {
        Console.WriteLine("Loại hình không hợp lệ!");
        i--;
        continue;
    }

    hinh.Nhap();
    danhSachHinh.Add(hinh);
}

// Tính và hiển thị kết quả
double tongChuVi = 0, tongDienTich = 0;
Console.WriteLine("\nKết quả:");
for (int i = 0; i < danhSachHinh.Count; i++)
{
    var hinh = danhSachHinh[i];
    double chuVi = hinh.TinhChuVi();
    double dienTich = hinh.TinhDienTich();
    tongChuVi += chuVi;
    tongDienTich += dienTich;
    Console.WriteLine($"Hình {i + 1}: Chu vi = {chuVi:F2}, Diện tích = {dienTich:F2}");
}

Console.WriteLine($"\nTổng chu vi: {tongChuVi:F2}");
Console.WriteLine($"Tổng diện tích: {tongDienTich:F2}");