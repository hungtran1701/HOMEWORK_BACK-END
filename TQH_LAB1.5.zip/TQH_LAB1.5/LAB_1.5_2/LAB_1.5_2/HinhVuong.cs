﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_1._5_2
{
    class HinhVuong : Hinh
    {
        private double canh;

        public override void Nhap()
        {
            Console.Write("Nhập cạnh: ");
            canh = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi() => 4 * canh;
        public override double TinhDienTich() => canh * canh;
    }
}
